import React from "react";
import { Link } from "react-router-dom";
import "./ArticlesCard.css";
import { Fade } from "react-reveal";

export default function ArticlesCard({ pub, theme }) {
  return (
    <div
      className="articles-card-div"
      style={{ backgroundColor: theme.highlight }}
    >
      <Fade bottom duration={2000} distance="40px">
        {/*
          Wrap the card contents in a Link so that clicking the article
          navigates within the app. The URL uses the article id defined in
          `src/portfolio.js` under `articles.data`.
        */}
        <Link
          to={`/blog/${pub.id}`}
          style={{ textDecoration: "none" }}
          key={pub.id}
        >
          <div className="articles-name-div">
            <p className="articles-name" style={{ color: theme.text }}>
              {pub.name}
            </p>
          </div>
          <p className="articles-description" style={{ color: theme.text }}>
            {pub.description}
          </p>
          <div className="articles-details">
            <p
              className="articles-creation-date subTitle"
              style={{ color: theme.secondaryText }}
            >
              Published on {pub.createdAt.split("T")[0]}
            </p>
          </div>
        </Link>
      </Fade>
    </div>
  );
}
