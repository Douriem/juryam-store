import React from "react";
import { useParams } from "react-router-dom";
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import TopButton from "../../components/topButton/TopButton";
import { articles } from "../../portfolio.js";

/*
 * ArticleDetail page
 *
 * This component renders a single blog article based on the `id` present
 * in the URL. It looks up the article in the `articles.data` array defined
 * in `portfolio.js` and displays its title, publication date, content and
 * an optional resume link. If the article does not exist, it shows a
 * simple fallback message.
 */
function ArticleDetail(props) {
  const { id } = useParams();
  const theme = props.theme;
  // Find the article with the matching id. The `id` fields in portfolio.js
  // should be unique strings. Falling back to `undefined` if not found.
  const article = articles.data.find((item) => item.id === id);

  if (!article) {
    return (
      <div className="article-detail-main">
        <Header theme={theme} />
        <div className="article-detail-content">
          <h1 style={{ color: theme.text }}>Article not found</h1>
        </div>
        <Footer theme={theme} />
        <TopButton theme={theme} />
      </div>
    );
  }

  return (
    <div className="article-detail-main">
      <Header theme={theme} />
      <div className="article-detail-content">
        <h1 style={{ color: theme.text }}>{article.name}</h1>
        <p className="subTitle" style={{ color: theme.secondaryText }}>
          Published on {article.createdAt.split("T")[0]}
        </p>
        <div className="article-body" style={{ color: theme.text }}>
          {/*
            The `content` field on each article should contain your full blog
            post as a string. For long articles (3000–4000 words) you may
            prefer to break the content into paragraphs, embed HTML or even
            parse Markdown. If no content is provided, the user sees a
            placeholder message.
          */}
          {article.content ? article.content : (
            <p>
              This article does not have any content yet. Update the
              <code>content</code> field in <code>src/portfolio.js</code> to add
              your blog post here.
            </p>
          )}
        </div>
        {/* Optional resume/CV link */}
        {article.resume && article.resume.trim() !== "" && (
          <p>
            <a
              href={article.resume}
              target="_blank"
              rel="noopener noreferrer"
              style={{ color: theme.accentColor }}
            >
              View Resume
            </a>
          </p>
        )}
      </div>
      <Footer theme={theme} onToggle={props.onToggle} />
      <TopButton theme={theme} />
    </div>
  );
}

export default ArticleDetail;